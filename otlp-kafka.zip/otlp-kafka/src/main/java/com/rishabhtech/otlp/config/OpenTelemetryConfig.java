package com.rishabhtech.otlp.config;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.contrib.kafka.KafkaSpanExporter;
import io.opentelemetry.contrib.kafka.KafkaSpanExporterBuilder;
import io.opentelemetry.sdk.OpenTelemetrySdk;
import io.opentelemetry.sdk.trace.SdkTracerProvider;
import io.opentelemetry.sdk.trace.data.SpanData;
import io.opentelemetry.sdk.trace.export.SimpleSpanProcessor;
import jakarta.annotation.PostConstruct;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;


@Configuration
public class OpenTelemetryConfig {

    private OpenTelemetry openTelemetry; // Holds the OpenTelemetry instance

    /**
     * Provides the OpenTelemetry bean to the Spring context.
     * This bean is used throughout the application for tracing.
     *
     * @return The configured OpenTelemetry instance.
     */
    @Bean
    public OpenTelemetry openTelemetry() {
        return openTelemetry;
    }

    /**
     * Initializes the OpenTelemetry SDK and configures it to export traces to Kafka.
     * This method is called automatically after the bean is constructed and dependencies are injected.
     */
    @PostConstruct
    public void init() {
        // Step 1: Configure Kafka producer properties
        Map<String, Object> producerConfig = new HashMap<>();
        producerConfig.put("bootstrap.servers", "localhost:29092"); // Kafka broker address
        producerConfig.put("acks", "all"); // Ensure all replicas acknowledge the message
        producerConfig.put("key.serializer", StringSerializer.class.getName()); // Serializer for keys
        producerConfig.put("value.serializer", StringSerializer.class.getName()); // Serializer for values

        // Step 2: Create a Kafka producer
        Producer<String, Collection<SpanData>> producer =
                new KafkaSpanExporterBuilder.ProducerBuilder()
                        .setConfig(producerConfig) // Pass the producer configuration
                        .build(); // Build the producer

        // Step 3: Create a KafkaSpanExporter to export traces to Kafka
        KafkaSpanExporter kafkaSpanExporter = new KafkaSpanExporterBuilder()
                .setTopicName("otel-traces") // Kafka topic for traces
                .setProducer(producer) // Set the Kafka producer
                .setTimeoutInSeconds(5) // Set a timeout for exporting
                .build(); // Build the exporter

        // Step 4: Set up the OpenTelemetry SDK with a tracer provider
        SdkTracerProvider tracerProvider = SdkTracerProvider.builder()
                .addSpanProcessor(SimpleSpanProcessor.create(kafkaSpanExporter)) // Add the Kafka exporter as a span processor
                .build(); // Build the tracer provider

        // Step 5: Build the OpenTelemetry instance
        // Use build() instead of buildAndRegisterGlobal() to avoid setting the global instance multiple times
        openTelemetry = OpenTelemetrySdk.builder()
                .setTracerProvider(tracerProvider) // Set the tracer provider
                .build(); // Build the OpenTelemetry instance
    }

    /**
     * Provides a Tracer bean to the Spring context.
     * The Tracer is used to create spans for tracing.
     *
     * @param openTelemetry The OpenTelemetry instance configured in this class.
     * @return A Tracer instance for creating spans.
     */
    @Bean
    public Tracer tracer(OpenTelemetry openTelemetry) {
        // Create and return a Tracer with the given name and version
        return openTelemetry.getTracer("my-spring-boot-app", "1.0.0");
    }
}
