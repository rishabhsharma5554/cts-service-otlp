package com.rishabhtech.otlp.controller;

import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Scope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
public class MyController {

    @Autowired
    private Tracer tracer;

    @GetMapping("/home")
    public String getHome()
    {
        String str =  UUID.randomUUID().toString();
        Span span = tracer.spanBuilder("sayHello").startSpan();
        try (Scope scope = span.makeCurrent()) {
            System.out.println("Random UUID Gerated : "+str);
            return str;
        } finally {
            span.end();
        }
    }
}
