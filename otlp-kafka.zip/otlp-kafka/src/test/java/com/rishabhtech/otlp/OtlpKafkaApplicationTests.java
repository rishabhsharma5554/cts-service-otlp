package com.rishabhtech.otlp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OtlpKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
